<!--Start Contact Us-->
<div class="container mt-4" id="Contact">
    <!--Start Contact Us Container-->
    <div class="col-sm text-center text-primary ">
      <br></br>
        <h1> <i class="fas fa-address-card mr-4"></i>Contact Us</h1>
        <br></br>
          </div>
    <div class="row">
      <!--Start Contact Us Row-->
      <div class="col-md-8">
        <!--Start Contact Us 1st Column-->
        <form action="" method="post">
          <input type="text" class="form-control" name="name" placeholder="Name"><br>
          <input type="text" class="form-control" name="subject" placeholder="Subject"><br>
          <input type="email" class="form-control" name="email" placeholder="E-mail"><br>
          <textarea class="form-control" name="message" placeholder="How can we help you?" style="height:150px;"></textarea><br>
          <input class="btn btn-primary" type="submit" value="Send" name="submit"><br><br>
        </form>
      </div> <!-- End Contact Us 1st Column-->

      <div class="col-md-4 stripe text-white text-center">
        <!-- Start Contact Us 2nd Column-->
        <h4>SRK Eduverse</h4>
        <p>Shubham,
          Gurhatta
          PATNA CITY, BIHAR<br />
          Phone: 7903082219 <br />
          www.srkeduverse.com </p>
      </div> <!-- End Contact Us 2nd Column-->
    </div> <!-- End Contact Us Row-->
  </div> <!-- End Contact Us Container-->
  <!-- End Contact Us -->

